const { FuzzySuggestModal, Notice, Plugin, PluginSettingTab, Setting, parseYaml, EditorSuggest } = require('obsidian');

// ==========================================
// 1. 默认设置
// ==========================================
const DEFAULT_SETTINGS = {
    dbPath: 'World_data.json'
};

// ==========================================
// 2. 核心渲染引擎 (无缝回退 + 别名覆盖)
// ==========================================
function renderEntity(type, lookupKey, overrides, db) {
    const category = (type === "spell" ? db.spells : db.traits) || {};
    
    // 1. 寻找原型数据 (支持 ID 和 名称检索，忽略大小写)
    let baseData = category[lookupKey];
    if (!baseData && lookupKey) {
        const lowerKey = String(lookupKey).toLowerCase();
        const foundKey = Object.keys(category).find(k => 
            k.toLowerCase() === lowerKey || 
            (category[k].name && category[k].name === lookupKey)
        );
        if (foundKey) baseData = category[foundKey];
    }

    // 2. 优雅降级：如果没找到原型，作为完全自定义的新卡片处理，不报错
    baseData = baseData || {};

    // 3. 合并数据：用户输入的 YAML 拥有最高优先级
    const finalData = Object.assign({}, baseData, overrides);
    
    // 4. 确定最终显示名称 (如果用户写了 name: 但留空，则回退使用 baseData.name)
    const displayName = overrides.name || baseData.name || lookupKey || "自定义" + (type === "spell" ? "法术" : "能力");

    // 5. 处理空描述，防止排版崩塌
    const descHtml = finalData.desc ? finalData.desc : `<span style="color:var(--text-muted); font-style:italic;">（暂无描述）</span>`;

    // 6. 构造并返回 HTML
    if (type === "spell") {
        return `
        <div class="fv-callout fv-spell">
            <div class="fv-header">
                <span class="fv-title">${displayName}</span>
                <span class="fv-cost">${finalData.cost || ""}</span>
            </div>
            <div class="fv-meta">
                ${finalData.target ? `<span><b>目标:</b> ${finalData.target}</span>` : ""}
                ${finalData.duration ? `<span><b>持续:</b> ${finalData.duration}</span>` : ""}
                ${finalData.check ? `<span><b>检定:</b> ${finalData.check}</span>` : ""}
            </div>
            <div class="fv-desc">${descHtml}</div>
        </div>`;
    } else {
        return `
        <div class="fv-callout fv-trait">
            <div class="fv-header">
                <span class="fv-title">${displayName}</span>
                <span class="fv-tag">${finalData.req ? `需求: ${finalData.req}` : "能力"}</span>
            </div>
            <div class="fv-desc">${descHtml}</div>
        </div>`;
    }
}

// ==========================================
// 3. 自动补全引擎 (代码块内输入提示)
// ==========================================
class FinalTaleEditorSuggest extends EditorSuggest {
    constructor(app, plugin) {
        super(app);
        this.plugin = plugin;
    }

    // 检测光标是否在指定的代码块内
    getBlockContext(editor, cursor) {
        let line = cursor.line;
        while (line >= 0) {
            const text = editor.getLine(line);
            if (text.startsWith('```spell')) return 'spell';
            if (text.startsWith('```ability')) return 'ability';
            if (text.trim() === '```' && line !== cursor.line) return null; 
            line--;
        }
        return null;
    }

    onTrigger(cursor, editor, file) {
        const blockType = this.getBlockContext(editor, cursor);
        if (!blockType) return null;

        const lineText = editor.getLine(cursor.line);
        const textBeforeCursor = lineText.substring(0, cursor.ch);

        // 场景 A: 正在输入 template 的值 (触发数据库查询)
        const templateMatch = textBeforeCursor.match(/^template:\s*(.*)$/);
        if (templateMatch) {
            this._contextType = 'value-template';
            this._blockType = blockType;
            return {
                start: { line: cursor.line, ch: textBeforeCursor.length - templateMatch[1].length },
                end: cursor,
                query: templateMatch[1],
                contextType: 'value-template',
                blockType: blockType
            };
        }

        // 场景 B: 正在输入属性名
        if (!textBeforeCursor.includes(':')) {
            const match = textBeforeCursor.match(/^\s*([a-zA-Z]*)$/);
            if (match) {
                this._contextType = 'key';
                this._blockType = blockType;
                return {
                    start: { line: cursor.line, ch: textBeforeCursor.length - match[1].length },
                    end: cursor,
                    query: match[1],
                    contextType: 'key',
                    blockType: blockType
                };
            }
        }
        return null;
    }

    getSuggestions(context) {
        const query = context.query.toLowerCase();
        // 兼容 Obsidian 不传递自定义字段的情况，回退到实例变量
        const contextType = context.contextType ?? this._contextType;
        const blockType   = context.blockType   ?? this._blockType;

        if (contextType === 'key') {
            const spellKeys = ['template', 'name', 'cost', 'target', 'duration', 'check', 'desc'];
            const abilityKeys = ['template', 'name', 'req', 'desc'];
            const keys = blockType === 'spell' ? spellKeys : abilityKeys;
            return keys.filter(k => k.startsWith(query)).map(k => ({ type: 'key', text: k }));
        }
        else if (contextType === 'value-template') {
            const db = this.plugin.database;
            const items = blockType === 'spell' ? db.spells : db.traits;
            const results = [];

            if (!items) return results;

            for (const [id, data] of Object.entries(items)) {
                if (id.toLowerCase().includes(query) || (data.name && data.name.includes(query))) {
                    results.push({ type: 'value', id: id, name: data.name });
                }
            }
            return results;
        }
        return [];
    }

    renderSuggestion(suggestion, el) {
        if (suggestion.type === 'key') {
            el.setText(suggestion.text + ": ");
        } else {
            // 左侧中文，右侧浅色英文ID
            el.style.display = "flex";
            el.style.justifyContent = "space-between";
            el.createDiv({ text: suggestion.name });
            el.createDiv({ text: suggestion.id, attr: { style: "color: var(--text-muted); font-size: 0.85em;" } });
        }
    }

    selectSuggestion(suggestion, evt) {
        const insertText = suggestion.type === 'key' ? suggestion.text + ": " : suggestion.id;
        this.context.editor.replaceRange(insertText, this.context.start, this.context.end);
    }
}

// ==========================================
// 4. 快捷插入面板 (Command Palette 调用)
// ==========================================
class EntitySuggestModal extends FuzzySuggestModal {
    constructor(app, items, blockType, editor) {
        super(app);
        this.items = items || {};
        this.blockType = blockType;
        this.editor = editor;
        this.setPlaceholder(`搜索并插入 ${blockType === "spell" ? "法术" : "能力"}...`);
    }

    getItems() { return Object.keys(this.items); }
    getItemText(item) { return `${this.items[item].name} (${item})`; }

    onChooseItem(item) {
        // 自动插入 template 并预留 name 字段方便改名
        const block = `\`\`\`${this.blockType}\ntemplate: ${item}\nname: \n\`\`\`\n`;
        this.editor.replaceSelection(block);
        
        // 将光标移动到 name: 的后面
        const cursor = this.editor.getCursor();
        this.editor.setCursor(cursor.line - 2, 6);
    }
}

// ==========================================
// 5. 插件设置面板
// ==========================================
class FinalTaleSettingTab extends PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }

    display() {
        const {containerEl} = this;
        containerEl.empty();
        containerEl.createEl('h2', {text: '最终物语 (Final Tale) - 数据库设置'});

        new Setting(containerEl)
            .setName('JSON 数据库路径')
            .setDesc('包含法术和能力的 JSON 文件在库中的相对路径 (如: World_Data.json)')
            .addText(text => text
                .setPlaceholder('World_Data.json')
                .setValue(this.plugin.settings.dbPath)
                .onChange(async (value) => {
                    this.plugin.settings.dbPath = value;
                    await this.plugin.saveSettings();
                    await this.plugin.loadDatabase();
                }));
    }
}

// ==========================================
// 6. Obsidian 插件主类注册
// ==========================================
module.exports = class FinalTalePlugin extends Plugin {
    async onload() {
        this.database = { spells: {}, traits: {} };
        await this.loadSettings();
        this.addSettingTab(new FinalTaleSettingTab(this.app, this));

        // 修复：确保数据库加载完成后，再注册代码块渲染器，防止首次打开笔记时渲染空白
        await this.loadDatabase(true);

        // 注册自动补全引擎
        this.registerEditorSuggest(new FinalTaleEditorSuggest(this.app, this));

        // 监听 JSON 文件的修改，实现热重载
        this.registerEvent(
            this.app.vault.on('modify', (file) => {
                if (file.path === this.settings.dbPath) {
                    this.loadDatabase(true); 
                }
            })
        );

        // 注册手动重载命令
        this.addCommand({
            id: 'reload-fv-database',
            name: '重载最终物语数据库',
            callback: () => this.loadDatabase()
        });

        // 注册法术快捷插入命令
        this.addCommand({
            id: 'insert-fv-spell',
            name: '插入法术 (Spell)',
            editorCallback: (editor) => {
                new EntitySuggestModal(this.app, this.database.spells, "spell", editor).open();
            }
        });

        // 注册能力快捷插入命令
        this.addCommand({
            id: 'insert-fv-ability',
            name: '插入职业能力 (Ability)',
            editorCallback: (editor) => {
                new EntitySuggestModal(this.app, this.database.traits, "ability", editor).open();
            }
        });

        // 注册代码块渲染器
        this.registerMarkdownCodeBlockProcessor("spell", (source, el) => this.processCodeBlock("spell", source, el));
        this.registerMarkdownCodeBlockProcessor("ability", (source, el) => this.processCodeBlock("ability", source, el));
    }

    async loadSettings() {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    }

    async saveSettings() {
        await this.saveData(this.settings);
    }

    async loadDatabase(silent = false) {
        try {
            let content;
            // 1. 优先尝试从 vault 中按路径读取（用户自定义数据文件）
            const vaultFile = this.app.vault.getAbstractFileByPath(this.settings.dbPath);
            if (vaultFile) {
                content = await this.app.vault.read(vaultFile);
            } else {
                // 2. 回退：从插件自身目录读取捆绑的数据文件
                const pluginPath = `${this.manifest.dir}/${this.settings.dbPath}`;
                content = await this.app.vault.adapter.read(pluginPath);
            }
            this.database = JSON.parse(content);
            this.database.spells = this.database.spells || {};
            this.database.traits = this.database.traits || {};

            if (!silent) new Notice("🔮 最终物语数据库已加载！");
        } catch (e) {
            console.error("Database Load Error:", e);
            if (!silent) new Notice("❌ 数据库解析失败，请检查 JSON 格式。");
        }
    }

    processCodeBlock(type, source, el) {
        try {
            const yaml = parseYaml(source) || {};
            // 现在的 template 是完全安全的，不会被 YAML 引擎拦截
            const lookupKey = yaml.template || yaml.id || yaml.source || yaml.name || "";
            
            const html = renderEntity(type, lookupKey, yaml, this.database);
            el.innerHTML = html;
        } catch (e) {
            el.innerHTML = `<div class="fv-callout"><span style="color:red;">⚠️ YAML 语法错误: ${e.message}</span></div>`;
        }
    }
}